
const header = document.querySelector('.header');
window.addEventListener('scroll', function() {
    if (this.scrollY > 32) {
        header.classList.add('small-header');
    } else {
        header.classList.remove('small-header');
    }
});

document.querySelector('#subscribe').addEventListener('click', () => alert(`M'sieur il marche pas le bouton !`));